<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
    <title>SWFUpload v2.0 Demo</title>

	<link href="css/default.css" rel="stylesheet" type="text/css" />

</head>
<body>
	<div class="title">SWFUpload v2.0 Demos</div>
	<div class="content">
		<b>SWFUpload v2.0 Demos</b>
		<ul>
			<li><a href="formsdemo/index.php">Classic Form Demo</a></li>
			<li><a href="multiuploaddemo/index.php">Multi-Instance Demo</a></li>
			<li><a href="featuresdemo/index.php">Features Demo</a></li>
			<li><a href="applicationdemo/index.php">Application Demo</a></li>
			<li><a href="v102demo/index.php">SWFUpload v1.0.2 Plugin Demo</a></li>
		</ul>
	</div>
</body>
</html>