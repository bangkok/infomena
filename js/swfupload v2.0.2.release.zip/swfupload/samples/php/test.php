<html>
<body>
	<form method="post" action="upload.php" enctype="multipart/form-data">
		<input type="file" name="Filedata" id="Filedata" />
		<input type="submit" value="Upload" />
	</form>
</body>
</html>